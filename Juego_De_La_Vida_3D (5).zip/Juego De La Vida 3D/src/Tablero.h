/*
 * Tablero.h
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */

#ifndef TABLERO_H_
#define TABLERO_H_
#include "Lista.h"
#include "Casillero.h"
#include "BitMap/bitmap.h"
#include <string>
#include <vector>
using namespace std;

class Tablero {
private:
	Lista<Lista<Lista<Casillero*>*>*>* tablero;
public:
	/**
	 * post: Se crea el tablero con las dimensiones indicadas.
	 */
	Tablero(unsigned int x, unsigned int y, unsigned int z);
	/**
	 * post: Se crea una copia del Tablero indicado.
	 */
	Tablero(Tablero &otroTablero);
	/**
	 * post: Establece el estado de la celula del casillero indicado.
	 */
	void setCasillero(int x, int y, int z, Estado estado);
	/**
	 * post: Inicializa todos los cursores y deja apuntando por defecto a la posicion (1,1,1).
	 */
	void iniciarTablero();
	/**
	 * post: Devuelve el casillero ubicado en la posicion indicada.
	 */
	Casillero * getCasillero(unsigned int x, unsigned int y, unsigned int z);
	/**
	 * post: Devuelve la cantidad de columnas.
	 */
	unsigned int getColumnas();
	/**
	 * post: Devuelve la cantidad de filas.
	 */
	unsigned int getFilas();
	/**
	 * post: Devuleve la cantidad de planos.
	 */
	unsigned int getPlanos();
	/**
	 * post:crea el archivo bitmap con el estado actual del tablero.
	 */
	void crearBitMapTablero(int tamanioPixel,const char* name);
	/**
	 * post: muestra el estado del tablero con caracteres.
	 */
	void mostrarTableroPorTerminal();
	/**
	 * pre: Todos los cursores tienen que estar iniciados.
	 * post:Indica si el cursor esta apuntano a la posicion indicada.
	 */
	bool compararPosiciones(unsigned int x, unsigned int y, unsigned int z);
	/**
	 * post: todas las celulas quedan con punteros a las celulas de alrededor.
	 */
	void cargarVecinos();
	void cargarDatosVector(vector<int> &datos);
	/**
	 * pre: El tablero tiene que existir.
	 * post: Limpia la memoria ocupada por el tablero.
	 */
	virtual ~Tablero();
private:
	/**
	 * pre:Todos los cursores tienen que estar iniciados.
	 * post: Coloca todos los cursores en el plano siguiente
	 */
	void avanzarPlano();
	/**
	 * post: Recorre los planos y carga las celulas de estos a la celula pasada por parametro.
	 */
	void analizarPlanos(Celula* aux, int &i, unsigned int x, unsigned int y, unsigned int z);
	/**
	 * post: Recorre las filas y llama a la funcion anterior.
	 */
	void analizarFilas(Celula* aux, int &i, unsigned int x, unsigned int y, unsigned int z);
	/**
	 * post: Recorre las columnas y llama a la funcion anterior.
	 */
	void analizarColumnas(Celula* aux, unsigned int x, unsigned int y, unsigned int z);
	/*
	PRE: y Son la cantidad de columnas
	POS: devuelve un in que seará la separacion entre los planos del bmp
	*/
	int ajustarChop(int y);
};

#endif /* TABLERO_H_ */
