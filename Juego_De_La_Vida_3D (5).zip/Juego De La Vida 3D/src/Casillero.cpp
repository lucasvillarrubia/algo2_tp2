/*
 * Casillero.cpp
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */

#include "Casillero.h"
#include "ctime"

Casillero::Casillero(unsigned int i, unsigned int j, unsigned int k){
	this->posicion.x=i;
	this->posicion.y=j;
	this->posicion.z=k;
	this->celula=new Celula();
	this->comportamiento=inerte;
}
Casillero::Casillero(Casillero &otroCasillero){
    this->posicion.x=otroCasillero.getPosicionX();
    this->posicion.y=otroCasillero.getPosicionY();
    this->posicion.z=otroCasillero.getPosicionZ();
    this->celula=new Celula(*otroCasillero.getCelula());
}

unsigned int Casillero::getPosicionX(){
	return (this->posicion.x);
}

unsigned int Casillero::getPosicionY(){
	return (this->posicion.y);
}

unsigned int Casillero::getPosicionZ(){
	return (this->posicion.z);
}

Celula* Casillero::getCelula(){
	return this->celula;
}

void Casillero::setComportamientoAleatorio(){
	unsigned int numeroAleatorio=rand();
	unsigned int comportamientoAleatorio=(numeroAleatorio%11);
	switch(comportamientoAleatorio){
		case 6:
			this->comportamiento=radiactivo;
			break;
		case 7:
			this->comportamiento=portal;
			break;
		case 8:
			this->comportamiento=bomba;
			break;
		case 9:
			this->comportamiento=potenciador;
			break;
		case 10:
			this->comportamiento=congelado;
			break;
		default:
			this->comportamiento=inerte;
			break;
	}
}

Comportamientos Casillero::getComportamiento(){
	return this->comportamiento;
}

Casillero::~Casillero() {
	if(this->celula){
		delete (this->celula);
	}
}

