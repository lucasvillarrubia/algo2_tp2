

#ifndef CELULA_H_
#define CELULA_H_

#include <random>
#include "Gen.h"
#include "AdministradorDeGen.h"
#include <vector>
#include <iostream>
using namespace std;

enum Estado{vivo,muerto};
enum FormaDeTransmision{Promedio,Primos,Maximo,MaxFormaDeTransmision};


//enum Genes{Alfa,Beta,Gamma,MAXGENES};


class Celula {
private:
	Estado estado;
	Celula* vecinos[26];
	FormaDeTransmision forma;			//se setea de forma aaleaotria por el juego!!!
	Gen* Alfa;
	Gen* Beta;
	Gen* Gamma;
public:
	static const int cantidadDeVecinos=26;

	/*
	POS: Construye una celula con estados BASE.
	*/
	Celula();
	/*
	POS Construye un cela a partir de los estados de otra
	*/
	Celula(Celula &otraCelula);
	/*
	PRE^: estado debe ser un parametro valido.
	POS: Setea el estado de la celua.
	*/
	void setEstado(Estado estado);
	/*
	PRE^: vecina debe ser un puntero a una celula dentro del tablero.
	POS: Setea  a vecina[i] como vecina de la celula instanciada.
	*/
	void setCelulaVecina(Celula* vecina, int i);
	/*
	Pre: i deba estar dentro de los parmetros validos.
	POS: Devielve un puntero ana vecina.
	*/
	Celula* getVecina(int i);
	/*
	Pos: Devuelve el estado de una Celua.
	*/
	Estado getEstado();
	/*
	Pos: Asigna de forma aleatoria  la forma de trensmicion de uan celula.
	*/
	void cargarRandFormaDeTransmision();
	/*
	Pos devuelve el la forma que se debe transmitir un gen.
	*/
	FormaDeTransmision getFormaDeTransmision();
	/*
	Pre: valor debe ser un numero entre 0 y 255;
	POS: Carga valor en el gen ALFA
	*/
	void setGenAlfa(unsigned int valor);
	/*
	Pre: valor debe ser un numero entre 0 y 255;
	POS: Carga valor en el gen BETA
	*/
	void setGenBeta(unsigned int valor);
	/*
	Pre: valor debe ser un numero entre 0 y 255;
	POS: Carga valor en el gen Gamma
	*/
	void setGenGamma(unsigned int valor);
	/*
	POS: Devuelve el valor del gen ALFA
	*/
	unsigned getGenAlfa(void);
	/*
	POS: Devuelve el valor del gen Beta
	*/
	unsigned getGenBeta(void);
	/*
	POS: Devuelve el valor del gen Gamma
	*/
	unsigned getGenGamma(void);
	/*
	POS: Setea un numero aleatorio en los genes
	*/
	void setGenesRAND();
	/*
	POS: Setea los genes en 0	
	*/
	void matarGenes();
	/*
	PRE: se carga un vector con los valores de genes de los vecinos vivos
	POS: Carga segun la forma los genes
	*/
	void setAlfaDeForma(vector<unsigned>* genes);
	/*
	PRE: se carga un vector con los valores de genes de los vecinos vivos
	POS: Carga segun la forma los genes
	*/
	void setBetaDeForma(vector<unsigned>* genes);
	/*
	PRE: se carga un vector con los valores de genes de los vecinos vivos
	POS: Carga segun la forma los genes
	*/
	void setGammaDeForma(vector<unsigned>* genes);
	/*
	POS: Devuelve la carga gentica amxiam de los genes.
	*/
	unsigned getMaxCargaGenetica();
	/*
	Pre: Debe exitir una  gen.
	POS: Destruye un gen y libera la memoria.
	*/
	void borrarGen(Gen*gen);
	/*
	PRE: Debe exitir una celula
	POS: Destruye y libera la memoria de uan celula.
	*/
	virtual ~Celula();

};

#endif /* CELULA_H_ */
