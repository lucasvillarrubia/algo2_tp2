/*
 * CargaDeDatos.h
 *
 *  Created on: 20 nov 2022
 *      Author: ivosu
 */

#ifndef CARGADEDATOS_H_
#define CARGADEDATOS_H_
#include <iostream>
#include <vector>

#include "ReadData.h"


using namespace std;

typedef enum{Automatico,Manual,MAXMODOS}FormaDeIngreso;
typedef enum{Chico,Mediano,Grande,CANTIDADDEMODS}DatosDeInicio;

/*
PRE: debe existir los TXT de datos
POS: Devuelve los datos de inicio 
*/
void cargaAutomatico(vector<int> &datos, vector<int> &config);
/*
PRE:Le pide al usuario que carge los datos de inicia
POS:Devuelve los datos inicio.
*/
void cargaManual(vector<int> &datos, vector<int> &config);
/*
PRE:
POS: LLama a la funcion que cargara los datos de inicio.
*/
void cargarDatos(vector<int> &datos, vector<int> &config);
/*
PRE: 
POS: Devuelve una forma de ingresar los datos.
*/
FormaDeIngreso textMetodoDeIngreso();
/*
PRE: Estar en modo Autmatico
POS: Es la forma de selecioanar un dato de entrada.
*/
DatosDeInicio textMetodoAutomatico();
/*
Pre:
POS: Le pide al usuario que carge la cantidad de turnos maximos jugables.
*/
void turnosMax(int * turnos);
/*
PRE
POS: Le pide al usuario que carge la resolucion de pixel a usar.
*/
void tamanioPixel(int * size);



FormaDeIngreso textMetodoDeIngreso(){
	char c;
	cout<<"Ingrese un numero: "<<endl;
	cout<<	"0)Para un ingreso Automatico. "<<endl<<
			"1)Para un ingreso Manual."<<endl;
	cin>>c;
	//cout<<c<<endl;
	return (FormaDeIngreso(c-'0'));
}

DatosDeInicio textMetodoAutomatico(){
	char c;
	cout<<"Se selecionó el modo automatico"<<endl<<
			"Existen 3 configuarciones pre-cargadas."<<endl<<
			"Ingrese un numero cargar una configuracion."<<endl<<
			"0)Para un tablero Chico con una baja dispersión de celulas vivas."<<endl<<
			"1)Para un tablero Mediano con una buena dispersión de celulas vivas."<<endl<<
			"2)Para un tablero Grande con sobre poblacion de celulas vivas."<<endl;
	cin>>c;

	return (DatosDeInicio(c-'0'));
}




void cargarDatos(vector<int> &datos, vector<int> &config){
	FormaDeIngreso modo;
	modo=textMetodoDeIngreso();
	//cout<<modo<<endl;


	while(modo>MAXMODOS){
		cout<<"El Metodo de carga de datos es incorecto."<<endl;
		modo=textMetodoDeIngreso();
	}

	if(modo==Manual){
		cargaManual(datos,config);
	}
	if(modo==Automatico){
		cargaAutomatico(datos,config);
	}
}
void cargaManual(vector<int> &dataVivas, vector<int> &dataTablero){

	int valor, x, y, z, r, g, b;
	string input;

	cout << "\nDimensiones del tablero:" << endl;
	cout << "Ingrese un ancho (x) para el tablero de juego:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);
	cout << "Ingrese un largo (y) para el tablero de juego:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);
	cout << "Ingrese una profundidad (z) para el tablero de juego:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);

	cout << "\nDatos de supervivencia celular:" << endl;
	cout << "Ingrese el número necesario para la reproducción:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);
	cout << "Ingrese el valor que representa 'soledad' celular:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);
	cout << "Ingrese el valor que representa 'sobrepoblación' celular:" << endl;
	cin >> valor;
	dataTablero.push_back(valor);

	cout << "\nCelulas vivas:" << endl;
	while (valor != 0){
		do{
			cout << "Ingrese coordenadas de una célula viva con la forma -> x;y;z" << endl;
			cout << "Las coordenadas tienen que estar dentro de los límites establecidos en el tablero." << endl;
			cin >> input;
			sscanf(input.c_str(), "%i;%i;%i\n", &x, &y, &z);
		}while(x>dataTablero.at(0) || y>dataTablero.at(1) || z>dataTablero.at(2));
		dataVivas.push_back(x);
		dataVivas.push_back(y);
		dataVivas.push_back(z);
		do{
			cout << "Ingrese los valores para los genes de una célula viva con la forma -> r;g;b" << endl;
			cout << "Los valores ingresados tienen que estar entre 0 y 255." << endl;
			cin >> input;
			sscanf(input.c_str(), "%i;%i;%i\n", &r, &g, &b);
		}while(r>255 || g>255 || b>255);
		dataVivas.push_back(r);
		dataVivas.push_back(g);
		dataVivas.push_back(b);
		cout << "Para terminar con la carga de datos, ingrese '0', para continuar ingrese cualquier otro número:" << endl;
		cin >> valor;
	}
}


void cargaAutomatico(vector<int> &datos, vector<int> &config){

	string nombre= "src/DataMap";
	string exten =".txt";
	string name;
	DatosDeInicio modo= textMetodoAutomatico();

	while(modo>CANTIDADDEMODS){
		cout<<"El datos es incorecto."<<endl;
		modo=textMetodoAutomatico();
	}
	name=nombre+string(to_string(modo))+exten;
	tomarDatosDeArchivoTXT(name,datos, config);
}

void turnosMax(int * turnos){
	int valor;
	cout << "Ingrese el número de turnos como máximo que tendrá la partida:" << endl;
	cin >> valor;
	*turnos = valor;
}

void tamanioPixel(int * size){
	int valor;
	cout << "Ingrese el tamaño de pixel que deseeentre 1 a 10:" << endl;
	cin >> valor;
	while(valor<1 || valor>10){
		cout << "ingresó un valor no valido, el tamaño debe estarentre 1 a 10, vuelva a intentralo. "<<endl;
		cin >> valor;
	}
	*size = valor;
}
#endif /* CARGADEDATOS_H_ */
