/*
 * bitmap.cpp
 *
 *  Created on: 16 nov. 2022
 *      Author: luis
 */
#include "bitmap.h"
using namespace std;

void createBMP(int x, int y, int size,const char* name,BMP * Sample){
 	Sample->SetSize(x*size,y*size);
 	Sample->SetBitDepth(8);
 	Sample->WriteToFile(name);
}

void setBigPixel(int x, int y, int size,int r, int g ,int b,const char* name,BMP * Sample){
 	RGBApixel rgb;
 	rgb.Red=r;
 	rgb.Green=g;
 	rgb.Blue=b;
 	rgb.Alpha=0;

 	for(int i=0;i<size;i++){
 		for(int j=0;j<size;j++){
 			Sample->SetPixel((x*size)+i, (y*size)+j, rgb);
 		}
 	}

}




