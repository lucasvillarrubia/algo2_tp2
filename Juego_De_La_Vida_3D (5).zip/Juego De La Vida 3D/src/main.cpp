/*
 * main.cpp
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */
#include <iostream>
#include "Tablero.h"
#include "Juego.h"
#include "ReadData.h"
#include "CargaDeDatos.h"
#include "ctime"

int main(){
	srand(time(NULL));
	vector<int> datos;
	vector<int> config;
	int turnos;
	int pixelSize;
/*
	for(int i=1;i<=30;i++){
		for(int j=1;j<=30;j++){
			for(int k=1;k<=5;k++){
				if(i==5 && (k==1 || k==3 || k==5)){
					cout<<i<<";"<<j<<";"<<k<<";"<<"30"<<";"<<"10"<<";"<<"90"<<";"<<endl;
				}
				if(i==10 && (k==1 || k==3 || k==5)){
					cout<<i<<";"<<j<<";"<<k<<";"<<"30"<<";"<<"255"<<";"<<"0"<<";"<<endl;
				}
				if(j==20 && (k==1 || k==3 || k==5)){
					cout<<i<<";"<<j<<";"<<k<<";"<<"100"<<";"<<"5"<<";"<<"9"<<";"<<endl;
				}
				if(j==25 && (k==1 || k==3 || k==5)){
					cout<<i<<";"<<j<<";"<<k<<";"<<"30"<<";"<<"255"<<";"<<"9"<<";"<<endl;
				}
			}
		}
	}
*/
	cargarDatos(datos, config);
	turnosMax(&turnos);
	tamanioPixel(&pixelSize);
	Juego* juego=new Juego(config[0], config[1], config[2], config[3], config[4], config[5], turnos,pixelSize);

	juego->ImprimirDatosDeEntrada();
	juego->cargarDatosDeEntrada(datos);

	juego->iniciarjuego();
	juego->jugarJuego();
	delete juego;
	return 0;
}

