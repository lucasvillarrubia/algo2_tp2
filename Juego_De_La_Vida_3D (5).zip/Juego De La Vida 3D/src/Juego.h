
#ifndef SRC_JUEGO_H_
#define SRC_JUEGO_H_
#include "Tablero.h"

#include <vector>
#include <string>


using namespace std;

#define CANTIDADDEDATOSPORFILA 6
#define  	 TERMINAR  	"X"
#define 	 UN_TURNO 	"C"
#define 	 REINICIAR 	"R"
#define 	 MAS_TURNOS "T"

enum EstadoJuego {
	INICIADO,
	JUGANDO,
	CONGELADO,
	REINICIADO,
	TERMINADO
};

enum TransmisionDeGenes{
	PROMEDIO,
	TRANSMISION2,
	TRANSMISION3
};

struct EstadisticasDelJuego{
	EstadoJuego estado;
	int turno;
	int nacimientosTotales;
	int muertesTotales;
	int nacidasEnTurno;
	int muertasEnTurno;
	int cantidadDeCelulasVivas;
};



class Juego {
private:
	Tablero* tablero;
	EstadisticasDelJuego estadisticas;
	vector<int> datosDeIngreso;

	int VALORDEREPRODUCCION;
	int VALORDESOLEDAD;
	int VALORDESOBREPOBLACION;
	int MAXTURNOS;
	int TAMANIODELPIXEL = 1;


	void actualizarJuego();
	bool checkInput(string input);
public:
	/**
	 * post: Crea el juego con las dimensiones del tablero, los valores de reproduccion, soledad y sobrepoblacion, los turnos maximos y el tamaño del pixel.
	 */
	Juego(int x, int y, int z, int valor, int soledad, int sobrepoblacion, int turnos,int sizePixel);
	/**
	 * post: Calcula y devuelve el promedio de nacimientos por turno.
	 */
	unsigned int getNacimientosPromedio();
	/**
	 * post: Calcula y devuelve el promedio de muertes por turno.
	 */
	unsigned int getMuertesPromedio();
	/**
	 * post: Devuelve el numero de turno.
	 */
	unsigned int getTurno();
	/**
	 * post: muestra por pantalla las opciones del usuario y solicita
	 */
	void jugarTurnos(int turnos);
	/**
	 * post: Inicializa las estadisticas en 0, muestra el tablero y crea el bitmap inicial.
	 */
	void iniciarjuego();
	/**
	 * post: Muestra por pantalla las opciones disponibles y solicita elegir la cantidad de turnos a ejecutar, terminar o reiniciar el juego.
	 */
	void jugarJuego();
	/**
	 * post: Actualiza al juego con las reglas de nacimiento, soledad y reproduccion.
	 */
	void implementarReglasSobreTablero();
	/**
	 * post: Decide si la célula del casillero debe vivir, morir o nacer.
	 */
	void implementarReglasSobreCasillero(Casillero* casillero);
	/**
	 * post: Suma un turno.
	 */
	void avanzarTurno();
	/**
	 * post: Termina el juego y muestra por pantalla las estadisticas finales.
	 */
	void terminarJuego();
	/**
	 * post: Deja los valores de las estadisticas en 0;
	 */
	void resetearEstadisticasDelJuego();
	/**
	 * post: Carga en el tablero las celulas con sus respectivos genes en las posiciones indicadas.
	 */
	void cargarDatosEntablero();
	/**
	 * post: Muestra por pantalla el fin del juego.
	 */
	void mostrarFinDeljuego();
	/**
	 * post: Muestra por pantalla las estadisticas.
	 */
	void mostrarEstadisticas();
	/**
	 * post: Carga los datos en datosDeIngreso.
	 */
	void cargarDatosDeEntrada(vector<int> &datos);
	/**
	 * post: Muestra por pantalla los datos ingresados.
	 */
	void ImprimirDatosDeEntrada();
	/**
	 * post: Recorre el tablero ejecutando el comportamiento de cada uno de los casilleros
	 */
	void ejecutarComportamientosDeCasilleros();
	/**
	 * post: Reduce los genes de la celula. Si los genes quedan en 0, la celula muere.
	 */
	void ejecutarComportamientoRadiactivo(Casillero* casillero);
	/**
	 * post: Duplica el nacimiento de la celula en otro casillero.
	 */
	void ejecutarComportamientoPortal(Casillero* casillero);
	/**
	 * post: Mata a la celula y a las celulas vecinas.
	 */
	void ejecutarComportamientoBomba(Casillero* casillero);
	/**
	 * post: Eleva los genes de la celula al maximo permitido.
	 */
	void ejecutarComportamientoPotenciador(Casillero* casillero);
	/**
	 * post: Mata a la celula pero sin dejar sus genes en 0.
	 */
	void ejecutarComportamientoCongelado(Casillero* casillero);
	/**
	 * post: Actualiza las estadisticas con las muertes y nacimientos que ocurrieron en el turno.
	 */
	void actualizarEstadisticas();
	/**
	 * post: Muestra por pantalla el estado del juego.
	 */
	void imprimirEstado();
	/**
	 * post: Libera la memoria ocupada por el juego.
	 */
	~Juego();
	/**
	 * post: Indica si el juego esta congelado o no.
	 */
	void chekConjelado();
};

#endif /* SRC_JUEGO_H_ */
