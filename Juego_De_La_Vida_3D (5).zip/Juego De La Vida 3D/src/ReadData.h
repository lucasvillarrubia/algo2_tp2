/*
 * ReadData.h
 *
 *  Created on: 13/11/2022
 *      Author: algo2
 */

#ifndef READDATA_H_
#define READDATA_H_

#include	<string>
#include 	<vector>
using namespace std;

/*
PRE rutaDatos debe ser un archivo de datos, datos es un espaciod e memorua donde se cargaran lso datos
    config es la configuracion basica del juego
POS devuelve los datos de organizados para leer.
*/
void tomarDatosDeArchivoTXT(const std::string rutaDatos, vector<int> &datos, vector<int> &config);


#endif /* READDATA_H_ */

