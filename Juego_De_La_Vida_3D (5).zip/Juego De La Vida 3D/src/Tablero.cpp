/*
 * Tablero.cpp
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */

#include "Tablero.h"
#include <iostream>

Tablero::Tablero(unsigned int x, unsigned int y, unsigned int z) {
	this->tablero=new Lista<Lista<Lista<Casillero*>*>*>();
	for (unsigned int i=1; i<=x; i++){
		Lista<Lista<Casillero*>*>* columna=new Lista<Lista<Casillero*>*>();
		for (unsigned int j=1; j<=y; j++){
			Lista<Casillero*>* fila=new Lista<Casillero*>();
			for (unsigned int k=1; k<=z; k++){
				Casillero* plano=new Casillero(i,j,k);
				fila->add(plano);
			}
			columna->add(fila);
		}
		this->tablero->add(columna);
	}

	this->cargarVecinos();
}

Tablero::Tablero(Tablero &otroTablero){
    this->tablero=new Lista<Lista<Lista<Casillero*>*>*>();
    for (unsigned int i=1; i<=otroTablero.getColumnas(); i++){
        Lista<Lista<Casillero*>*>*columna=new Lista<Lista<Casillero*>*>();
        for (unsigned int j=1; j<=otroTablero.getFilas(); j++){
            Lista<Casillero*>*fila=new Lista<Casillero*>();
            for (unsigned int k=1; k<=otroTablero.getPlanos(); k++){
                Casillero*plano=new Casillero(*otroTablero.getCasillero(i,j,k));
                fila->add(plano);
            }
            columna->add(fila);
        }
        this->tablero->add(columna);
    }
    this->cargarVecinos();
}

void Tablero::setCasillero(int x, int y, int z, Estado estado){
	this->tablero->get(x)->get(y)->get(z)->getCelula()->setEstado(estado);
}

void Tablero::iniciarTablero(){
	this->tablero->reiniciarCursor();
	this->tablero->avanzarCursor();
	for (unsigned int i=1; i<=this->tablero->contarElementos(); i++){
		this->tablero->getCursor()->reiniciarCursor();
		this->tablero->getCursor()->avanzarCursor();
		for(unsigned int j=1; j<=this->tablero->getCursor()->contarElementos(); j++){
			this->tablero->getCursor()->getCursor()->reiniciarCursor();
			this->tablero->getCursor()->getCursor()->avanzarCursor();
			this->tablero->getCursor()->avanzarCursor();
		}
		this->tablero->avanzarCursor();
	}
}

Casillero * Tablero::getCasillero(unsigned int x, unsigned int y, unsigned int z){
	return this->tablero->get(x)->get(y)->get(z);
}

unsigned int Tablero::getColumnas(){
	return this->tablero->contarElementos();
}

unsigned int Tablero::getFilas(){
	this->iniciarTablero();
	return this->tablero->getCursor()->contarElementos();
}

unsigned int Tablero::getPlanos(){
	this->iniciarTablero();
	return this->tablero->getCursor()->getCursor()->contarElementos();
}
int Tablero::ajustarChop(int y){
	if(y<5){
		return 1;
	}
	return y/5;
}

void Tablero::crearBitMapTablero(int tamanioPixel,const char* name){
	BMP BITMAP;
	cout<<name<<endl;
	int X=this->getColumnas();
    int Y=this->getFilas();
    int Z=this->getPlanos();
    int chop=ajustarChop(Y);
    int acumulado=0;
    createBMP(((Z*X)+(Z-1)*chop),Y, tamanioPixel,name,&BITMAP);
    Celula * c;
    for(int z=0;z<Z;z++){
    	for(int x=0;x<X;x++){
			for(int y=0;y<Y;y++){
				c = this->getCasillero(x+1, y+1, z+1)->getCelula();
				setBigPixel( x+acumulado,y,tamanioPixel ,c->getGenAlfa(),c->getGenBeta(),c->getGenGamma(),name,&BITMAP);
			}
		}
    	acumulado+=X+chop;
    	cout<<"Planos Impresos "<<z+1<<" / "<<Z<<endl;
    }
    BITMAP.WriteToFile(name);

}

void Tablero::mostrarTableroPorTerminal(){
	this->iniciarTablero();
	for(unsigned int k=1; k<=this->tablero->getCursor()->getCursor()->contarElementos(); k++){
		for(unsigned int i=1; i<=this->tablero->getCursor()->contarElementos(); i++){
			for(unsigned int j=1; j<=this->tablero->contarElementos(); j++){
				if(this->tablero->getCursor()->getCursor()->getCursor()->getCelula()->getEstado()==vivo){
					std::cout<<"[0]";
				}else{
					std::cout<<"[ ]";
				}
				this->tablero->getCursor()->avanzarCursor();
				this->tablero->avanzarCursor();
			}
			std::cout<<std::endl;
		}
		this->avanzarPlano();
		std::cout<<"\n"<<std::endl;
	}
}



bool Tablero::compararPosiciones(unsigned int x, unsigned int y, unsigned int z){
	if (this->tablero->getCursor()->getCursor()->getCursor()->getPosicionX()==x){
		if (this->tablero->getCursor()->getCursor()->getCursor()->getPosicionY()==y){
			if (this->tablero->getCursor()->getCursor()->getCursor()->getPosicionZ()==z){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}else{
		return false;
	}
}

void Tablero::cargarVecinos(){
	this->iniciarTablero();
	for(unsigned int k=1; k<=this->tablero->getCursor()->getCursor()->contarElementos(); k++){
		for(unsigned int i=1; i<=this->tablero->contarElementos(); i++){
			for(unsigned int j=1; j<=this->tablero->getCursor()->contarElementos(); j++){
				Celula* aux=this->tablero->getCursor()->getCursor()->getCursor()->getCelula();
				this->analizarColumnas(aux, i, j, k);
			}
			this->tablero->avanzarCursor();
		}
		this->avanzarPlano();
	}
}

void Tablero::cargarDatosVector(vector<int>& datos){
	Celula * c;
	for(int i=0; i<datos.size(); i+=6){
		c = this->getCasillero(datos[i],datos[i+1],datos[i+2])->getCelula();
		c->setEstado(vivo);
		c->setGenAlfa(datos[i+3]);
		c->setGenBeta(datos[i+4]);
		c->setGenGamma(datos[i+5]);
	}
}

void destruirPlano(Lista<Lista<Casillero*>*>*plano){
	Lista<Casillero*>* listaDeCasilleros;
	for(unsigned i = 1; i <= plano->contarElementos(); i++){
		listaDeCasilleros = plano->getCursor();
		for(unsigned j = 1; j <= listaDeCasilleros->contarElementos(); j++ ){
			delete listaDeCasilleros->getCursor();
			if(j != listaDeCasilleros->contarElementos()){
				listaDeCasilleros->avanzarCursor();
			}
		}
		delete listaDeCasilleros;
		if(i != plano->contarElementos())
			plano->avanzarCursor();
	}
	delete plano;
}


Tablero::~Tablero(){
	this->iniciarTablero();

	Lista<Lista<Casillero*>*>* plano;

	for(unsigned i = 1; i <= tablero->contarElementos(); i++){
		plano = tablero->getCursor();
		destruirPlano(plano);
		if(i != tablero->contarElementos())
			tablero->avanzarCursor();
	}

	delete tablero;
}
void Tablero::avanzarPlano(){
	for(unsigned int i=1; i<=this->tablero->contarElementos(); i++){
		for(unsigned int j=1; j<=this->tablero->getCursor()->contarElementos(); j++){
			this->tablero->getCursor()->getCursor()->avanzarCursor();
			this->tablero->getCursor()->avanzarCursor();
		}
		this->tablero->avanzarCursor();
	}
}

void Tablero::analizarPlanos(Celula* aux, int &i, unsigned int x, unsigned int y, unsigned int z){
	for(int j=0; j<3; j++){
		if (j==0){
			this->tablero->getCursor()->getCursor()->retrocederCursor();
		}else{
			this->tablero->getCursor()->getCursor()->avanzarCursor();
		}
		if (!this->compararPosiciones(x, y, z)){
			aux->setCelulaVecina(this->tablero->getCursor()->getCursor()->getCursor()->getCelula(), i);
			i++;
		}
	}
}

void Tablero::analizarFilas(Celula* aux, int &i, unsigned int x, unsigned int y, unsigned int z){
	for (int j=0; j<3; j++){
		if (j==0){
			this->tablero->getCursor()->retrocederCursor();
		}else{
			this->tablero->getCursor()->avanzarCursor();
		}
		this->analizarPlanos(aux, i, x, y, z);
		this->tablero->getCursor()->getCursor()->retrocederCursor();
	}
}

void Tablero::analizarColumnas(Celula* aux, unsigned int x, unsigned int y, unsigned int z){
	int k=0;
	while (k<26){
		if (k==0){
			this->tablero->retrocederCursor();
		}else{
			this->tablero->avanzarCursor();
		}
		this->analizarFilas(aux, k, x, y, z);
	}
	this->tablero->retrocederCursor();
}
