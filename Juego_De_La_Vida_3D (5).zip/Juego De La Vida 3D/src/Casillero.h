/*
 * Casillero.h
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */

#ifndef CASILLERO_H_
#define CASILLERO_H_
#include "Celula.h"





struct Posicion{
	unsigned int x;
	unsigned int y;
	unsigned int z;
};

enum Comportamientos{
	inerte,
	radiactivo,
	portal,
	bomba,
	potenciador,
	congelado
};

class Casillero {
private:
	Celula* celula;
	Posicion posicion;
	Comportamientos comportamiento;

public:
	/*
	PRE: (ijk) deben estar entre 0<(ijk)<los maximos cargados 
	POS: Crea un casilliero 
	*/
	Casillero(unsigned int i, unsigned int j, unsigned int k);
	/*
	PRE: otroCasillero debe exitir
	POS: Crea un casillor a partir de otro
	*/
	Casillero(Casillero &otroCasillero);
	/*
	POS:Devuelve la posision de un casillero. 
	*/
	unsigned int getPosicionX();
	/*
	POS:Devuelve la posision de un casillero. 
	*/
	unsigned int getPosicionY();
	/*
	POS:Devuelve la posision de un casillero. 
	*/	
	unsigned int getPosicionZ();
	/*
	POS:Devuelve un puntero a celula situada en ese casillero. 
	*/
	Celula* getCelula();
	/*
	POS:Setea un comportamiento aleatorio del casillero.
	*/
	void setComportamientoAleatorio();
	/*
	POS Devuelve el comportamiento
	*/
	Comportamientos getComportamiento();
	/*
	POS Destruye el casillero y libera la memoria Pedida.
	*/
	virtual ~Casillero();
};

#endif /* CASILLERO_H_ */
