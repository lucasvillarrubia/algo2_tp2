

/*
 * Celula.cpp
 *
 *  Created on: 11 oct. 2022
 *      Author: luis
 */

#include "Celula.h"

Celula::Celula() {
	this->Alfa=new Gen(0);
	this->Beta=new Gen(0);
	this->Gamma=new Gen(0);
	this->estado=muerto;
	this->cargarRandFormaDeTransmision();
}

Celula::Celula(Celula &otraCelula){
    this->Alfa=new Gen(otraCelula.getGenAlfa());
    this->Beta=new Gen(otraCelula.getGenBeta());
    this->Gamma=new Gen(otraCelula.getGenGamma());
    this->estado=otraCelula.getEstado();
    this->forma=otraCelula.forma;
    this->cargarRandFormaDeTransmision();
}

void Celula::cargarRandFormaDeTransmision(){
	int forma=rand();
	this->forma=(FormaDeTransmision)(forma % MaxFormaDeTransmision);
}

FormaDeTransmision Celula::getFormaDeTransmision(){
	return this->forma;
}
void Celula::setEstado(Estado estado){
	this->estado=estado;
}

void Celula::setCelulaVecina(Celula* vecina, int i){
	this->vecinos[i]=vecina;
}

Celula* Celula::getVecina(int i){
	Celula* vecina=vecinos[i];
	return vecina;
}

Estado Celula::getEstado(){
	return this->estado;
}
void Celula::setAlfaDeForma(vector<unsigned>* genes){
	AdministradorDeGen* aGen = new AdministradorDeGen();
	if(this->forma==Primos){
		//this->Alfa=aGen->generarGenPorCargaMediaDePrimos(genes);
		this->Alfa=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Promedio){
		this->Alfa=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Maximo){
		this->Alfa=aGen->generarGenPorMaximo(genes);

	}

}
void Celula::setBetaDeForma(vector<unsigned>* genes){
	AdministradorDeGen* aGen = new AdministradorDeGen();
	if(this->forma==Primos){
		//this->Beta=aGen->generarGenPorCargaMediaDePrimos(genes);
		this->Beta=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Promedio){
		this->Beta=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Maximo){
		this->Beta=aGen->generarGenPorMaximo(genes);

	}

}
void Celula::setGammaDeForma(vector<unsigned>* genes){
	AdministradorDeGen* aGen = new AdministradorDeGen();
	if(this->forma==Primos){
		//this->Gamma=aGen->generarGenPorCargaMediaDePrimos(genes);
		this->Gamma=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Promedio){
		this->Gamma=aGen->generarGenPorPromedio(genes);
	}
	if(this->forma==Maximo){
		this->Gamma=aGen->generarGenPorMaximo(genes);

	}

}

void Celula::setGenAlfa(unsigned int valor){
	this->Alfa->setCargaGenetica(valor);
}
void Celula::setGenBeta(unsigned int valor){
	this->Beta->setCargaGenetica(valor);
}
void Celula::setGenGamma(unsigned int valor){
	this->Gamma->setCargaGenetica(valor);
}
void Celula::matarGenes(){
	this->Alfa->setCargaGenetica(0);
	this->Beta->setCargaGenetica(0);
	this->Gamma->setCargaGenetica(0);
}

void Celula::setGenesRAND(){
	unsigned int genAleatorio1=rand();
	unsigned int genAleatorio2=rand();
	unsigned int genAleatorio3=rand();
	this->Alfa->setCargaGenetica(genAleatorio1 % (this->Alfa->CARGAGENETICAMAX+1));
	this->Beta->setCargaGenetica(genAleatorio2 % (this->Beta->CARGAGENETICAMAX+1));
	this->Gamma->setCargaGenetica(genAleatorio3 % (this->Gamma->CARGAGENETICAMAX+1));
}
unsigned Celula::getGenAlfa(){
	return this->Alfa->getCargaGenetica();
}

unsigned Celula::getGenBeta(){
	return this->Beta->getCargaGenetica();
}
unsigned Celula::getGenGamma(){
	return this->Gamma->getCargaGenetica();
}

unsigned Celula::getMaxCargaGenetica(){
	return this->Alfa->getMaximoDeCargaGenetica();
}

Celula::~Celula() {
	borrarGen(this->Alfa);
	borrarGen(this->Beta);
	borrarGen(this->Gamma);
}
void Celula::borrarGen(Gen* gen){
	if(gen != NULL){
		delete gen;
	}

}

