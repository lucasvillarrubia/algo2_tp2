/*
 * Gen.cpp
 *
 *  Created on: 13 nov 2022
 *      Author: camac
 */



#include "Gen.h"
#include <iostream>

using namespace std;

Gen::Gen(unsigned int cargaGenetica){
	verificar(cargaGenetica);
	this->cargaGenetica = cargaGenetica;
}

unsigned int Gen::getCargaGenetica(){
		return cargaGenetica;
}

void Gen::setCargaGenetica(int cargaGenetica) {
	verificar(cargaGenetica);
	this->cargaGenetica = cargaGenetica;
}


void Gen::verificar( unsigned int cargaGenetica ){
	if( cargaGenetica < 0 || cargaGenetica > CARGAGENETICAMAX){
		throw "cargaGenetica debe ser un entero mayor o igual que cero y menor o igual que maximoDeCArgaGenetica";
	}
}

unsigned int Gen::getMaximoDeCargaGenetica(){
	return this->CARGAGENETICAMAX;
}
