//============================================================================
// Name        : ReadData.cpp
// Author      : ivo
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "ReadData.h"
#include	<fstream>
#include	<iostream>
#include	<cstdlib>
using namespace std;


void tomarDatosDeArchivoTXT(const std::string rutaDatos,vector<int> &datos, vector<int> &config){


	size_t pos=0;
	std::string separador=";";
	std::ifstream entrada;
	entrada.open(rutaDatos.c_str());
	std::string line;
	std::string dato;


	std::getline(entrada,line);

	//DEFINICONES
	while((pos=line.find(separador)) != std::string::npos){
		dato =line.substr(0,pos);
		config.push_back(stoi(dato));
		line.erase(0,pos+1);
	}

	//DATOS
	while(!entrada.eof()){
		std::getline(entrada,line);
		while((pos=line.find(separador)) != std::string::npos){
			dato =line.substr(0,pos);

			datos.push_back(stoi(dato));
			line.erase(0,pos+1);
		}
	}

	entrada.close();
}


